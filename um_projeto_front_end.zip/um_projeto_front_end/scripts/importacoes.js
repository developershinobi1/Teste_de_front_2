fetch('../../index.html')
  .then(resposta => resposta.text())
  .then(html => {
    const documento = new DOMParser().parseFromString(html, 'text/html');

    const headerExport = documento.querySelector('.header_export');
    const headerDestino = document.querySelector('header');

    if (headerExport && headerDestino) {
      headerDestino.appendChild(headerExport);
    }
  });
  
const navbar_controll_start = document.querySelector(".navbar_controll .burguer")
const navbar_controll_exit= document.querySelector(".navbar_controll .exitburguer")

const navbar_caixa= document.querySelector(".header_export .header_navbar")

navbar_controll_start.addEventListener("click", () => {
    if (!navbar_caixa.classList.contains("ativada")) {
      
        navbar_controll_exit.style.display = 'block'
        navbar_controll_start.style.display = 'none'
        navbar_caixa.classList.toggle("ativada")
    }
})

navbar_controll_exit.addEventListener("click", () => {
  
    if (navbar_caixa.classList.contains("ativada")) {
      
        navbar_controll_exit.style.display = 'none'
        navbar_controll_start.style.display = 'block'
        navbar_caixa.classList.toggle("ativada")
    }
})


// ativação da barra de pesquisa _____________________$$$



const lupa_exit = document.querySelector(".menu_pesquisa .exitPesquisa")
const lupa_start = document.querySelector(".lupa_controll .lupa")

const pesquisa_box = document.querySelector(".header_menu_central .menu_pesquisa")

lupa_start.addEventListener("click", () => {
  
    if (!pesquisa_box.classList.contains("ativada")) {
        pesquisa_box.classList.toggle("ativada")
    }
})
lupa_exit.addEventListener("click", () => {
  
    if (pesquisa_box.classList.contains("ativada")) {
        pesquisa_box.classList.toggle("ativada")
    }
})