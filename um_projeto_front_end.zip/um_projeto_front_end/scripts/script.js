//limpar a caixa de exibir todos os resultados
function esvaziar_todos_os_resultados(acao){
  
  
  if (acao === 'exibir') {
    
    if (!lista_todos_os_resultados.classList.contains("ativada")) {
      lista_todos_os_resultados.innerHTML = ' '
      lista_todos_os_resultados.classList.add('ativada');
    }else{
      
      lista_todos_os_resultados.innerHTML = ' '
      
    }
  }
  
// ativação da navbar _____________________$$$

  else if (acao === 'ocultar') {
    if (lista_todos_os_resultados.classList.contains("ativada")) {
      lista_todos_os_resultados.innerHTML = ' '
      lista_todos_os_resultados.classList.remove('ativada');
    }
  }
    
  
}

const navbar_controll_start = document.querySelector(".navbar_controll .burguer")
const navbar_controll_exit= document.querySelector(".navbar_controll .exitburguer")

const navbar_caixa= document.querySelector(".header_export .header_navbar")

navbar_controll_start.addEventListener("click", () => {
    if (!navbar_caixa.classList.contains("ativada")) {
      
        navbar_controll_exit.style.display = 'block'
        navbar_controll_start.style.display = 'none'
        navbar_caixa.classList.toggle("ativada")
    }
})

navbar_controll_exit.addEventListener("click", () => {
  
    if (navbar_caixa.classList.contains("ativada")) {
      
        navbar_controll_exit.style.display = 'none'
        navbar_controll_start.style.display = 'block'
        navbar_caixa.classList.toggle("ativada")
    }
})


// ativação da barra de pesquisa _____________________$$$



const lupa_exit = document.querySelector(".menu_pesquisa .exitPesquisa")
const lupa_start = document.querySelector(".lupa_controll .lupa")

const pesquisa_box = document.querySelector(".header_menu_central .menu_pesquisa")

lupa_start.addEventListener("click", () => {
  
    if (!pesquisa_box.classList.contains("ativada")) {
        pesquisa_box.classList.toggle("ativada")
    }
})
lupa_exit.addEventListener("click", () => {
  
    if (pesquisa_box.classList.contains("ativada")) {
        pesquisa_box.classList.toggle("ativada")
    }
})


// ativação de categorias

//tudo

const cat_tudo = document.querySelector(".cat_tudo")

// apenas os nomes masculinos
const cat_nomes = document.querySelector(".cat_nome_mas")

//apenas frutas
const cat_frutas = document.querySelector(".cat_frutas")

// todas as caixas
const todas_as_categorias = document.querySelectorAll(".categoria")

// categoria nomes masculinos
const caixa_nomes_cat = document.querySelector(".nomes_mas")

//categorias frutas
const caixa_frutas_cat = document.querySelector(".frutas")


//filtra os itens pela categoria

function filtrar(dado1,dado2){
  esvaziar_todos_os_resultados('ocultar')
  dado1.forEach((dados) => {
    
    dados.style.display = 'none'
    
  })
  
  dado2.style.display = 'flex'
  
}


// filtra por frutas

cat_frutas.addEventListener("click", () => {

filtrar(todas_as_categorias,caixa_frutas_cat)
  
  
})


// filtra por nomes

cat_nomes.addEventListener("click", () => {

filtrar(todas_as_categorias,caixa_nomes_cat)
  
  
})

// coloca os itens de volta

cat_tudo.addEventListener("click", () => {

  esvaziar_todos_os_resultados('ocultar')
  todas_as_categorias.forEach((dados) => {
    
    dados.style.display = 'flex'
    
  })
  
})


// script relativo ao sistema de pesquisa

const caixa_texto_pesquisa = document.querySelector(".text_pesquisa")
const caixa_resultado_pesquisa = document.querySelector(".pesquisa_result")
const sinalizador_de_pesquisa = document.querySelector(".results_extra_contagem")
const onde_pesquisar = document.querySelectorAll(".enderecos")

// essa função trata se a entrada de pesquisa do usuário é valida ou não

function validarPesquisa(value) {

    // Remove espaços das extremidades e normaliza o texto
    const texto = value
        .toLowerCase()
        .trim()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '');

    // Se não sobrou nada, não existe pesquisa
    if (texto === '') {
        return '';
    }

    // Permite somente letras, números e espaços
    if (!/[a-z0-9]/.test(texto)) {
        return '';
    }

    // Repetição exagerada do mesmo caractere
    if (/(.)\1{3,}/.test(texto)) {
        return '';
    }

    // Remove caracteres que não interessam à pesquisa
    return texto.replace(/[^a-z0-9\s]/g, '');
}


    // Função para tratar o texto (deixa minúsculo, sem acentos e sem espaços desnecessários)
function formatString(value) {
  return value
    .toLowerCase()
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}
    
let todos_os_resultados = []



    
caixa_texto_pesquisa.addEventListener('input', (event) => {
      const valor = event.target.value
      const value = validarPesquisa(event.target.value);
      let notResults = true;
      caixa_resultado_pesquisa.innerHTML = ' '
      todos_os_resultados.length = 0
      
      contagem = 1
      
      if (value !== '') {
        onde_pesquisar.forEach((item) => {
          // Captura APENAS o Título e o Subtítulo
          const itemTitle = item.querySelector('.title').textContent;
          const itemdescription = item.querySelector('.description').textContent;

          // Verifica se a busca coincide APENAS com Título ou Subtítulo
          const matchesTitle = formatString(itemTitle).indexOf(value) !== -1;
          const matchesdescription = formatString(itemdescription).indexOf(value) !== -1;

          if (matchesTitle || matchesdescription) {
            
            todos_os_resultados.push(item)
            if (contagem < 7){
              const li = document.createElement('li');
              
              li.innerHTML = `
                  ${item.outerHTML}
                  <i class="fa-solid fa-arrow-right seta"></i>
              `;
              caixa_resultado_pesquisa.appendChild(li);
            }
            contagem += 1
          
            notResults = false;
          
          }    
          
        });

        // Se houver resultados, esconde a mensagem. Caso contrário, exibe.
        if (notResults) {
         
          sinalizador_de_pesquisa.innerHTML = ` nenhum resultado encontrado `
          
        }else{
          
          if ( todos_os_resultados.length < 7){
           sinalizador_de_pesquisa.innerHTML = `foram encontrados estes resultados`;
          }else{
            
           sinalizador_de_pesquisa.innerHTML = ` há +${todos_os_resultados.length - 6}, ver tudo. `;
            
          }
          
          
        }
        
      } else {
        
        if (valor === '' ){
      
          sinalizador_de_pesquisa.innerHTML = `  faça a sua pesquisa `
          
        } else {
          
          sinalizador_de_pesquisa.innerHTML = ` digite algo válido! `
        
        }
      }
    
  });
  
  
 // todos_os_resultados serão exibidos no home principal
  
const lista_todos_os_resultados = document.querySelector(".todos_os_resultados")
const sinalizador_todos_os_resultados = document.querySelector(".results_extra")

sinalizador_todos_os_resultados.addEventListener('click',() => { 
  
  if (todos_os_resultados.length > 6){
    esvaziar_todos_os_resultados('exibir')
    lista_todos_os_resultados.innerHTML = ' <h1 class="name_categoria"> resultado da pesquisa: </h1>'
    
    todos_os_resultados.forEach((item) => {
      
      const li = document.createElement('li');
                
      li.innerHTML = `${item.outerHTML}`;
      li.className = 'card';
      lista_todos_os_resultados.appendChild(li);
      
    })
    
    lista_todos_os_resultados.innerHTML += ` <div class="botao">
              
              carregar mais
              
            </div>`
            
            
    prepararCarregarMais(lista_todos_os_resultados)
  }
})

// de carregar cards

function prepararCarregarMais(lista) {
  const cards = [...lista.querySelectorAll(':scope > li.card')];
  const botao = lista.querySelector(':scope > .botao');

  if (!botao) return;

  const quantidadeInicial = 3;
  const quantidadePorClique = 3;

  cards.forEach((card, indice) => {
    if (indice >= quantidadeInicial) {
      card.classList.add('oculto');
    } else {
      card.classList.remove('oculto');
    }
  });

  botao.style.display =
    cards.length > quantidadeInicial ? 'block' : 'none';

  botao.onclick = () => {
    const escondidos = cards.filter(card =>
      card.classList.contains('oculto')
    );

    escondidos.slice(0, quantidadePorClique).forEach(card => {
      card.classList.remove('oculto');
    });

    const aindaEscondidos = cards.some(card =>
      card.classList.contains('oculto')
    );

    if (!aindaEscondidos) {
      botao.style.display = 'none';
    }
  };
}

// Inicializa as categorias que já existem no HTML
document.querySelectorAll('main .categoria').forEach(lista => {
  prepararCarregarMais(lista);
});
